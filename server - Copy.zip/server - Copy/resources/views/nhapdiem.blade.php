<form action="{{route('diem')}}" method="GET">
	<input type="number" name="diem">
	<input type="submit" >
</form>