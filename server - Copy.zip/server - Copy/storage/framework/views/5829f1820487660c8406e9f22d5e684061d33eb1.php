<form action="<?php echo e(route('diem')); ?>" method="GET">
	<input type="number" name="diem">
	<input type="submit" >
</form><?php /**PATH C:\xampp\htdocs\laravel\server\resources\views/nhapdiem.blade.php ENDPATH**/ ?>